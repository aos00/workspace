#ifndef CommunitationUtils_h
#define CommunitationUtils_h

void serialPrintFloatArr(float * arr, int length);
void serialFloatPrint(float f);

#endif // CommunitationUtils_h